
package javaapplication2;

import java.util.Scanner;

public class Demo12 {
    public static void tinhChuViDienTich()//ĐỊnh nghĩa hàm
    {
        Scanner s = new Scanner(System.in);//doi tuong nhap lieu
        //b1. Nhap chieu dai
        System.out.println("Chieu dai=");
        double chieudai = s.nextDouble();
        //b2. Nhap chieu rong
        System.out.println("Chieu rong=");
        double chieurong = s.nextDouble();
        //B3. tinh
        double chuvi = (chieudai+chieudai)*2;
        double dientich = chieudai*chieurong;
        //B4. In
        System.out.println("Chu vi la: "+chuvi);
        System.out.println("Dien tich la: "+dientich);
    }
    public static void theTichHinhLapPhuong()//dinh nghia ham
    {
        //Math.pow(x,3);// ham so mu
        Scanner s = new Scanner(System.in);//doi tuong nhap lieu
        //b1. Nhap chieu dai
        System.out.println("Chieu dai=");
        double chieudai = s.nextDouble();
        //b2. Tinh the tich
        double thetich = Math.pow(chieudai, 3);
        //b3. In ra man hinh
        System.out.println("The tich la: "+thetich);
    }
    public static void main(String[] args) {
        tinhChuViDienTich();//gọi hàm
    }
}
