
package javaapplication2;//tên package: giống các tòa nhà F,P,L

import java.util.Scanner;

public class JavaApplication2 {//tên lớp: P204, P205,P206

    public static void main(String[] args) {//hàm main: điểm bắt đầu chương trình
        Scanner s = new Scanner(System.in);
        //1.Nhap ho ten
        System.out.println("Ho ten");
        String hoten = s.nextLine();//nhap chuoi
        //2.nhap diem
        System.out.println("Diem");
        double diem = s.nextDouble();
        //3. In ra man hinh
        System.out.println("Ban vua nhap: "+hoten+" - "+diem);//dau + la noi chuoi
        //System.out.printf("%s %.1f",hoten,diem);
        
    }
    
}
