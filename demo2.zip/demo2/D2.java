package demo2;

public class D2 {
    public static void main(String[] args) {
        IT17327 sv = new IT17327();//tạo đối tượng mới
        //sv.gptb1();//gọi hàm nằm trong đối tượng
        //sv.gptb2();
        //sv.tintiendien();
        sv.menu();
    }
}
