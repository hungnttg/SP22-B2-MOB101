package demo2;

import java.util.Scanner;

public class IT17327 {
    public void gptb1()//dinh nghia ham
    {
        Scanner s = new Scanner(System.in);
        //1.Nhap he so a,b
        System.out.println("a="); int a = s.nextInt();//nhap a
        System.out.println("b="); int b = s.nextInt();//nhap b
        //2. Tinh toan
        float x = ((float)-b/a);
        System.out.println("Ngiem x="+x);//in ra ket qua
    }
    public void gptb2()
    {
        Scanner s = new Scanner(System.in);
        //1.Nhap he so a,b
        System.out.println("a="); int a = s.nextInt();//nhap a
        System.out.println("b="); int b = s.nextInt();//nhap b
        System.out.println("c="); int c = s.nextInt();//nhap c
        //2. Tinh toan
        float delta = b*b-4*a*c;
        if(a==0)
        {
            System.out.println("Day la ptb1");
            gptb1();//gọi bài toán gptb1
        }
        else
        {
            if(delta<0)
            {
                System.out.println("PTVN");
            }
            else if(delta==0)
            {
                System.out.println("PT co nghiem kep x="+((float)-b/(2*a)));
            }
            else
            {
                float x1 = ((float)(-b+Math.sqrt(delta)/(2*a)));
                float x2 = ((float)(-b-Math.sqrt(delta)/(2*a)));
                System.out.println("PT co 2 nghiem x1="+x1+" va x2="+x2);
            }
        }
    }
    public void tintiendien()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Nhap so dien");
        double soDien = s.nextDouble();
        double tongTien = 0;
        if(soDien<50)
        {
            tongTien = soDien*1000;
        }
        else
        {
            tongTien = (soDien-50)*1200+50*1000;
        }
        System.out.println("Tong tien: "+tongTien);
    }
    public void menu()
    {
        System.out.println("Moi ban chon chuc nang");
        System.out.println("-----------------------");
        System.out.println("1. Giai phuong trinh bac 1");
        System.out.println("2. Giai phuong trinh bac 2");
        System.out.println("3. Tinh tien dien");
        System.out.println("-----------------------");
        Scanner s = new Scanner(System.in);
        int chucnang = s.nextInt();
        switch(chucnang)
        {
            case 1:
                 gptb1();
                 break;
            case 2:
                 gptb2();
                 break;
            case 3:
                 tintiendien();
                 break;
            default:
                System.out.println("Khong co chuc nang tren");
                break;
        }
    }
}
