
package demo3;

public class D3 {
    public static void main(String[] args) {
        Lab3 l = new Lab3();//tao moi doi tuong
        //l.ktSNT();//goi ham
        //l.inBangCuuChuong();
        //l.nhapXuatMang();
        l.mang_hoten_diem();
    }
}
