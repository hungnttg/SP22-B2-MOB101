package demo3;

import java.util.Arrays;
import java.util.Scanner;

public class Lab3 {
    public void ktSNT()
    {
        //1. Nhap lieu
        Scanner s = new Scanner(System.in);
        System.out.println("---Kiem tra so nguyen to---");
        System.out.println("a=");
        int a = s.nextInt();
        //2. Tinh toan
        boolean giaSuALaSNT = true;//bien dieu khien
        int i = 2;
        while(i<a)
        {
            if(a%i==0)//neu a chia het cho 1 so khac 1 va chinh no
            {
                giaSuALaSNT = false;
            }
            i++;
        }
        if(giaSuALaSNT==true)
        {
            System.out.println(a+" la so nguyen to");
        }
        else
        {
             System.out.println(a+" khong phai la so nguyen to");
        }
    }
    public void inBangCuuChuong()
    {
        for(int x=1;x<=10;x++)
        {
            System.out.println("-------------");
            for(int i = 1;i<=10;i++)
            {
                System.out.printf("%d x %d = %d\n",x,i,x*i);
            }
        }
    }
    public void nhapXuatMang()
    {
        System.out.println("---Nhap mang so nguyen-----");
        Scanner s = new Scanner(System.in);
        //B1 - Tao 1 mang gom 5 phan tu
        int[] a = new int[5];
        //B2 - Nhap du lieu vao mang qua vong lap
        for(int i=0;i<a.length;i++)
        {
            //a[i] = Integer.parseInt(s.nextLine());
            a[i] = s.nextInt();
        }
        System.out.println("----Mang ban vua nhap----");
        //B3 - In ra mang vua nhap (doc du lieu tu mang)
        for(int j=0;j<a.length;j++)
        {
            System.out.println(a[j]);
        }
        //b4- Sap xep mang
        Arrays.sort(a);//sap xep tu nho den lon
        //B5 -  In ra mang moi sap xep
        System.out.println("---Mang sau khi sap xep---");
        for(int j=0;j<a.length;j++)
        {
            System.out.println(a[j]);
        }
        //B6 - Tinh trung binh cong cua cac so chia het cho 3
        int tong=0, dem = 0;
        for(int k=0;k<a.length;k++)
        {
            if(a[k]%3==0)//neu phan tu chia het cho 3
            {
                tong += a[k];
                dem++;
            }
        }
        float tbc =((float)tong/dem);
        System.out.println("Trung binh cong cac so chia het cho 3 la "+tbc);
    }
    public void mang_hoten_diem()
    {
        System.out.println("---Nhap ho ten va diem--------");
        Scanner s = new Scanner(System.in);
        String[] hoTen = new String[4];
        String[] hocLuc = new String[4];
        double[] diem = new double[4];
        //b1 - nhap du lieu
        for(int i=0;i<hoTen.length;i++)
        {
            System.out.println("Ho ten:");
            hoTen[i] = s.nextLine();
            System.out.println("Diem:");
            diem[i] = s.nextDouble();
            s.nextLine();//lam sach luong dem khi nhap chuoi truoc roi nhap so sau
            if(diem[i]<5)
            {
                hocLuc[i] = "Yeu";
            }
            else if(diem[i]<6.5)
            {
                hocLuc[i] = "TB";
            }
            else if(diem[i]<8)
            {
                hocLuc[i] = "Kha";
            }
            else if(diem[i]<=10)
            {
                hocLuc[i] = "Gioi";
            }
        }
        //b2 - in ra man hinh thong tin vua nhap
        System.out.println("---Ban vua nhap cac thong tin sau-------");
        for(int j=0;j<hoTen.length;j++)
        {
            System.out.printf("Ho ten: %s; Diem: %.1f; HocLuc: %s\n",
                    hoTen[j],diem[j],hocLuc[j]);
        }
        //b3 - sap xep theo diem
        for(int i=0;i<hoTen.length;i++)
        {
            for(int j=0;j<hoTen.length;j++)
            {
                if(diem[i]>diem[j])
                {
                    //hoan vi diem
                    double tam = diem[i];
                    diem[i] = diem[j];
                    diem[j] = tam;
                    //hoan vi hoc luc
                    String htTam = hoTen[i];
                    hoTen[i] = hoTen[j];
                    hoTen[j] = htTam;
                    //hoan vi hoc luc
                    String hlTam = hocLuc[i];
                    hocLuc[i] = hocLuc[j];
                    hocLuc[j] = hlTam;
                    
                }
            }
        }
        //b4- in mang sau khi sap xep
        System.out.println("----Mang sau khi sap xep----");
        for(int k=0;k<hoTen.length;k++)
        {
             System.out.printf("Ho ten: %s; Diem: %.1f; HocLuc: %s\n",
                    hoTen[k],diem[k],hocLuc[k]);
        }
    }
}
