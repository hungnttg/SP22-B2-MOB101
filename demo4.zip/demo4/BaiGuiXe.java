package demo4;//toa nha
public class BaiGuiXe {//lop
    //Dinh nghia các bien
    public String mauson;
    public String hangxe;
    public int soBanh;
    //Dinh nghia cac ham
    public void di()
    {
        System.out.println("Xe co the di thang, re phai, re trai");
    }
    public void no()
    {
        System.out.println("Xe may no brum");
    }
}
