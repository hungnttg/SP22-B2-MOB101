
package demo4;

public class BaiXeMay2 {
    //Dinh nghia các bien
    private String mauson;
    private String hangxe;
    private int soBanh;
    //b4 - viết code
    //this.thuocTinh1 => truy cập vào thuộc tính 1 của đối tượng hiện thời
    //this.ham1() => truy cập vào ham1() của đối tượng hiện thời
    //super.thuocTinh2 => truy cập vào biến 2 của đối tượng cha
    //super.ham2() => truy cập vào hàm 2 của đối tượng cha
    //this: đối tượng hiện thời
    //super: đối tượng cha
    //b1 - Tạo hàm khởi tạo có tham số
    public BaiXeMay2(String mauson, String hangxe, int soBanh) {
        this.mauson = mauson;
        this.hangxe = hangxe;
        this.soBanh = soBanh;
    }
    //b2 - Tạo hàm khởi tạo không có tham số
    public BaiXeMay2() {
    }
    //b3 - Tạo getter và setter
    public String getMauson() {
        return mauson;
    }

    public void setMauson(String mauson) {
        this.mauson = mauson;
    }

    public String getHangxe() {
        return hangxe;
    }

    public void setHangxe(String hangxe) {
        this.hangxe = hangxe;
    }

    public int getSoBanh() {
        return soBanh;
    }

    public void setSoBanh(int soBanh) {
        this.soBanh = soBanh;
    }
    
    
    
}
