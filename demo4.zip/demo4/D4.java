package demo4;
public class D4 {
    public static void main(String[] args) {
//        BaiGuiXe xeDream = new BaiGuiXe();//lay xe tu bai xe
//        xeDream.no();//no may
//        xeDream.di();//chay
//        SanPham s1 = new SanPham();
//        s1.nhap();
//        s1.xuat();
//        
//        SanPham s2 = new SanPham();
//        s2.nhap();
//        s2.xuat();
        
        SanPham s3 = new SanPham("San Pham 3",9999,11);
        s3.xuat();

    }  
}
