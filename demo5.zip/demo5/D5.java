
package demo5;


public class D5 {
    public static void main(String[] args) {
//        SoThuc st = new SoThuc();//tao moi doi tuong so thuc
//        st.nhapSoThuc();//goi ham nhap so thuc
//        st.xuatSoThuc();//goi ham xuat so thuc
        
        SinhVien sv = new SinhVien();
        sv.nhap();
        sv.xuat();
        sv.sapXepNgauNhien();
        sv.sapXepTangDan();
        sv.sapXepTangDan();
        sv.xoa();
        sv.xoaTatCa();
    }
}
