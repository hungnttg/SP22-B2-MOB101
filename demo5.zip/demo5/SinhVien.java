package demo5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class SinhVien {
  private String hoTen;
    ArrayList<String> arr = new ArrayList<>();//khoi tao mang dong
    public void nhap()
    {
        Scanner s = new Scanner(System.in);
        String qd;//quyet dinh nhap tiep hay khong
        boolean yn=true;//bien dieu khien vong lap nhap lieu
        while(yn)//vong lap nhap lieu
        {
            System.out.println("Moi nhap ho ten: ");
            hoTen = s.nextLine();//nhap ho ten
            arr.add(hoTen);//them ho ten vao mang dong
            System.out.println("y/n");//co nhap tiep khong
            qd = s.nextLine();//nguoi dung nhap quyet dinh y hoac n
            switch(qd)
            {
                case "y":
                    yn=true;
                    break;
                case "n":
                    yn=false;
                    break;
                default:
                    System.out.println("Chi nhap y hoac n");
            }
        }
        System.out.println("----Ket thuc nhap lieu------");
    }
    public void xuat()
    {
        System.out.println("---Danh sach sinh vien vua nhap------");
        for(String x: arr)//dung foreach de doc du lieu tu mang dong
        {
            System.out.println(x);//in ra sinh vien x
        }
    }
    public void sapXepNgauNhien()
    {
        System.out.println("----Sap xep ngau nhien-----");
        Collections.shuffle(arr);//sap xep ngau nhien
        for(String x: arr)//in ra cac phan tu
        {
            System.out.println(x);
        }  
    }
    public void sapXepTangDan()
    {
        System.out.println("---Sap xep tang dan-------");
        Collections.sort(arr);//sap xep tang dan
        for(String x: arr)//in ra cac phan tu
        {
            System.out.println(x);
        }     
    }
    public void sapXepGiamDan()
    {
        System.out.println("----Sap xep giam dan-----");
        Collections.sort(arr);//sap xep tang dan
        Collections.reverse(arr);//dao nguoc lai sap xep tang dan
        for(String x: arr)
        {
            System.out.println(x);
        }
    }
    public void xoa()
    {
        System.out.println("---Xoa phan tu----");
        System.out.println("---Truoc khi xoa----");
        xuat();//goi ham xuat du lieu de in du lieu ra man hinh
        Scanner s = new Scanner(System.in);//tao luong nhap lieu
        System.out.println("Nhap ho ten can xoa");
        hoTen = s.nextLine();//nhap ho ten can xoa tu ban phim
        for(String x:arr)//duyet mang dong
        {
            if(x.equalsIgnoreCase(hoTen))//neu x chua ho ten
            {
                arr.remove(x);//xoa doi tuong x
                break;//thoat khoi vong lap
            }
        }
        System.out.println("----Sau khi xoa----");
        xuat();//goi ham xuat de in du lieu ra man hinh   
    }
    public void xoaTatCa()
    {
        System.out.println("---Xoa tat ca cac phan tu---");
        arr.clear();//xoa tat ca
        System.out.println("---sau khi xoa tat ca---");
        xuat();//goi ham xuat de in du lieu ra man hinh
    }
}
