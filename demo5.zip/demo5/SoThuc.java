package demo5;

import java.util.ArrayList;
import java.util.Scanner;

public class SoThuc {
   private ArrayList<Double> arr;// khai báo mảng động
   public void nhapSoThuc()
   {
       arr = new ArrayList<>();//khởi tạo mảng động
       Scanner s = new Scanner(System.in);
       while(true)
       {
           Double a = s.nextDouble();//nhap vao bien a
           arr.add(a);//dua a vao mang dong
           s.nextLine();//lam sach luong dem
           System.out.println("Co nhap tiep khong? (y/n)");//dua ra thong bao
           String kq = s.nextLine();//nguoi dung nhap y hoac n
           if(kq.equals("n"))//neu nhap no
           {
                break;//thoat khoi vong lap
           }
       }
   }
   public void xuatSoThuc()
   {
       System.out.println("Mang dong vua nhap");
       double tong = 0;//khai bao tong
       for(Double x: arr)
       {
           tong+=x;//cong don cac phan tu
           System.out.println(x.toString());//in ra cac phan tu
       }
       System.out.println("Tong la: "+tong);//in ra tong
   }
}
