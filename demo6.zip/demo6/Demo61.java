package demo6;

import java.util.Scanner;

public class Demo61 {
    public static void main(String[] args) {
        String fullname = "";
        Scanner s = new Scanner(System.in);//luong nhap
        System.out.println("Moi ban nhap ho ten");
        fullname = s.nextLine();//nhap vao bien fullname
        //xac dinh dau cach dau tien
        int kyTuTrangDauTien = fullname.indexOf(" ");
        //xac dinh dau cach cuoi cung
        int kyTuTrangCuoiCung = fullname.lastIndexOf(" ");
        //tach chuoi
        //subString: ham lay chuoi con
        //ho.length: lấy về độ dài của biến họ
        String ho = fullname.substring(0,kyTuTrangDauTien)
                .toUpperCase();
        String dem = fullname.substring(kyTuTrangDauTien,kyTuTrangCuoiCung);
        String ten = fullname.substring(kyTuTrangCuoiCung,
                fullname.length()).toUpperCase();
        System.out.printf("Ho ten: %s %s %s",ho,dem,ten);
    }
}
