package demo6;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Demo62 {
    public static void main(String[] args) {
        List<SanPham> arrSanpham = new ArrayList<>();//danh sach sp
        Scanner s = new Scanner(System.in);//luong nhap
        while(true)
        {
            System.out.println("Moi nhap Ten - Cong ty - Gia");
            SanPham sp = new SanPham();//tao doi tuong chua du lieu
            sp.setName(s.nextLine());//nhap ten tu ban phim
            sp.setComp(s.nextLine());//nhap cong ty tu ban phim
            sp.setPrice(s.nextDouble());//nhap gia tu ban phim
            arrSanpham.add(sp);//dua san pham vua nhap vao list
            s.nextLine();//lam sach luong dem (do nhap so->chu)
            System.out.println("Co nhap tiep khong (y/n)");
            String kq = s.nextLine();//nhan y hoac n tu ban phim
            if(kq.equals("n"))
            {
                break;//thoat khoi vong lap
            }
        }
        //in ra cac san pham vua nhap
        System.out.println("Cac san pham Nokia vua nhap");
        for(SanPham sp1: arrSanpham)
        {
            if(sp1.getComp().equalsIgnoreCase("Nokia"))
            {
                System.out.println(sp1.getName()+" - "
                        +sp1.getComp()+" - "+sp1.getPrice());
        }
    }
 
}
}
