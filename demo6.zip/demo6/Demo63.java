package demo6;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Demo63 {
    public static void main(String[] args) {
        List<HocSinh> arrHS = new ArrayList<>();//tao danh sach chua hoc sinh
        Scanner s = new Scanner(System.in);//tao luong nhap lieu
        String regEmail = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
        String regPhone = "0[0-9]{9,10}";
        String regCMT = "[0-9]{9}";
        while(true)
        {
            System.out.println("Moi nhap: Ten-Email-Phone-CMT");
            HocSinh hs = new HocSinh();//tao moi doi tuong hoc sinh
            hs.name = s.nextLine();//nhap ten tu ban phim
            hs.email = s.nextLine();//nhap email tu ban phim
            //kiem tra email dung khong
            if(!hs.email.matches(regEmail))//neu khong dung dinh dang
            {
                System.out.println("Khong dung dinh dang email, moi nhap lai");
                continue;//bo qua lan lap hien tai, sang lan lap moi
            }
            hs.phone = s.nextLine();//nhap so dien thoai
            //kiem tra so dien thoai xem cos dung khong
            if(!hs.phone.matches(regPhone))//neu dien thoai k dung
            {
                System.out.println("Khong dung dinh dang Phone, moi nhap lai");
                continue;//bo qua lan lap hien tai, sang lan lap moi
            }
            hs.cmt = s.nextLine();//nhap cmt
            //kiem tra cmt xem dung khong
            if(!hs.cmt.matches(regCMT))//neu cmt khong dung
            {
                System.out.println("Khong dung dinh dang CMT, moi nhap lai");
                continue;//bo qua lan lap hien tai, sang lan lap moi
            }
            arrHS.add(hs);//them hoc sinh vao mang
            //s.nextLine();//lam sach luong dem
            System.out.println("Co nhap tiep khong (y/n)");
            String kq = s.nextLine();
            if(kq.equals("n"))
            {
                break;//thoat khoi vong lap
            }
            
        }
        
    }
}
