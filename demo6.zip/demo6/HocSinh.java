package demo6;

public class HocSinh {
    public String name;
    public String email;
    public String phone;
    public String cmt;
}
