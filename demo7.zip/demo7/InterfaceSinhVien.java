
package demo7;

public interface InterfaceSinhVien {
    public void nhap();
    public void xuat();
    public double getDiemTB();
}
