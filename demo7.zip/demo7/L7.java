
package demo7;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class L7 {
    public static void main(String[] args) {
        List<SinhVienIT> arrIt = new ArrayList<>();
        Scanner s1 = new Scanner(System.in);
        while(true)
        {
            System.out.println("---Nhap SV IT----");
            SinhVienIT it = new SinhVienIT();//tao doi tuong
            it.nhap();//nhap lieu cho sv IT
            arrIt.add(it);//them vao arrayList
            System.out.println("Co nhap tiep khong (y/n)");
            String kq = s1.nextLine();
            if(kq.equals("n"))//neu nhap n
            {
                break;//thoat khoi vong lap
            }
        }
        //Xuat danh sach nhap SV IT
        System.out.println("Xuat SV IT");
        for(SinhVienIT svit: arrIt)
        {
            svit.xuat();
        }
        //xuat danh sach SV co hoc luc gioi
        System.out.println("Xuat SV IT co hoc luc gioi");
        for(SinhVienIT svit: arrIt)
        {
            if(svit.getDiemTB()>=8)
            {
                svit.xuat();
            }
            
        }
        //sap xep sinh vien
        System.out.println("sap xep theo diem");
        List<SinhVienIT> listSapXep = new ArrayList<>();
        for(int i=0;i<arrIt.size();i++)
        {
            for(int j=0;j<arrIt.size();j++)
            {
                if(arrIt.get(i).getDiemTB()>arrIt.get(j).getDiemTB())
                {
                   listSapXep.add(arrIt.get(j));
                }
            }
        }
    }
}
