package demo7;

public class SinhVien implements InterfaceSinhVien{

    @Override
    public void nhap() {
        
    }

    @Override
    public void xuat() {
        
    }

    @Override
    public double getDiemTB() {
       return 0;
    }
    public String hoTen;
    public String nganh;
    public String getHocLuc()
    {
        String xepLoai="";
        if(getDiemTB()<5)
        {
            xepLoai="Yeu";
        }
        else if(getDiemTB()<6.5)
        {
            xepLoai="Trung Binh";
        }
        else if(getDiemTB()<8)
        {
            xepLoai="Kha";
        }
        else if(getDiemTB()<=10)
        {
            xepLoai="Gioi";
        }
        return xepLoai;
    }
    
}
