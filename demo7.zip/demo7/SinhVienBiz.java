package demo7;

import java.util.Scanner;

public class SinhVienBiz extends SinhVien{
   private double diemMKT, diemSale;

    @Override
    public void nhap() {
        Scanner s = new Scanner(System.in);
        System.out.println("Nhap SV Biz: HoTen-Nganh-DiemMKT-DiemSale");
        super.hoTen = s.nextLine();//truy xuat ho ten tu lop cha
        super.nganh = s.nextLine();//truy xuat nganh tu lop cha
        this.diemMKT = s.nextDouble();//truy xuat diemMKT tu lop con
        this.diemSale = s.nextDouble();//truy xuat diemSale tu lop con
        System.out.println("---ket thuc nhap lieu cho SV Biz----");
    }
    @Override
    public void xuat() {
        System.out.println("Xuat thong tin Sinh vien Biz");
        System.out.printf("HoTen: %s; Maketing: %.1f; Sale: %.1f",
                super.hoTen,this.diemMKT,this.diemSale);
    }
   
}
