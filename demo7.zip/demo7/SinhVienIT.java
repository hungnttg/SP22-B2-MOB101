package demo7;

import java.util.Scanner;

public class SinhVienIT extends SinhVien{
    private double diemJava, diemHTML, diemCSS;

    @Override
    public double getDiemTB() {
        return (2*diemJava+diemHTML+diemCSS)/4;
    }

    @Override
    public void nhap() {
        Scanner s = new Scanner(System.in);
        System.out.println("Nhap SV IT: HoTen-Nganh-DiemJava-DiemHTML-DiemCSS");
        super.hoTen = s.nextLine();//truy xuat ho ten tu lop cha
        super.nganh = s.nextLine();//truy xuat nganh tu lop cha
        this.diemJava = s.nextDouble();//truy xuat diemJava tu lop con
        this.diemHTML = s.nextDouble();//truy xuat diemHtml tu lop con
        this.diemCSS = s.nextDouble();//truy xuat diemCSS tu lop con
        System.out.println("---ket thuc nhap lieu cho SV IT----");
    }
     //super: cha; this: con
    @Override
    public void xuat() {
        System.out.println("Xuat thong tin Sinh vien IT");
        System.out.printf("HoTen: %s; Java: %.1f; HTML: %.1f; CSS: %.1f",
                super.hoTen,this.diemJava,this.diemHTML,this.diemCSS);
    }
    

   
    
    
}
