package demo8;

public class L8 {
    public static void main(String[] args) {
        System.out.printf("Tinh tong: %.1f\n",XPoly.sum(1,2,5,8,10));
        System.out.printf("Min: %.1f\n",XPoly.min(-100,2,-8,8,10,20));
        System.out.printf("Max: %.1f\n",XPoly.max(-100,2,-8,8,10,20));
        System.out.printf("Thuong sang Hoa: %s\n",
                XPoly.toUpperFistChar("nguyen phan van teo"));
    }
}
