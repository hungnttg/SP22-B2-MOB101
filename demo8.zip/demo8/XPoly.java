package demo8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final public class XPoly {
    public static double sum(double...ts)
    {
        double tong=0;
        for(double a: ts)//cho vao vong lap for
        {
            tong+=a;//cong don vao tong
        }
        return tong;
    }
    public static double min(double...ts)
    {
        //list chua danh sach tham so
        List<Double> ls = new ArrayList<>();
        for(double a: ts)
        {
            ls.add(a);//đưa các tham số vào list
        }
        //sap xep danh sach theo thu tu tu nho den lon
        Collections.sort(ls);
        return ls.get(0);//tra ve gia tri nho nhat
    }
    public static double max(double...ts)
    {
        List<Double> ls = new ArrayList<>();
        for(double a: ts)
        {
            ls.add(a);
        }
        Collections.sort(ls);
        return ls.get(ls.size()-1);
    }
    public static String toUpperFistChar(String str)
    {
        String[] arrs = str.split(" ");//cat chuoi dua vao dau cach
        String chuoiMoi = "";
        for(int i=0;i<arrs.length;i++)
        {
            char kyTuDau = arrs[i].charAt(0);//lay phan tu dau tien
            //chuyen sang chu hoa
            char kyTuDauVietHoa
                    =String.valueOf(kyTuDau).toUpperCase().charAt(0);
            //mang moi: T+eo
            arrs[i] = kyTuDauVietHoa+arrs[i].substring(1);
            chuoiMoi+=arrs[i]+" ";
        }
        return chuoiMoi;
    }
}
